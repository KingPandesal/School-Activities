﻿namespace Madayag_W4W3
{
    partial class lblTitle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblHoursWorked = new System.Windows.Forms.Label();
            this.lblRatePerHour = new System.Windows.Forms.Label();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.txtHoursWorked = new System.Windows.Forms.TextBox();
            this.txtRatePerHour = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCompute = new System.Windows.Forms.Button();
            this.dgvAllEmployees = new System.Windows.Forms.DataGridView();
            this.dgvEmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvHoursWorked = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvRatePerHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvGrossPay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDeduction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvNetPay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllEmployees)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(319, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Simple Payroll System";
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Location = new System.Drawing.Point(27, 279);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(125, 20);
            this.lblEmployeeName.TabIndex = 1;
            this.lblEmployeeName.Text = "Employee Name";
            // 
            // lblHoursWorked
            // 
            this.lblHoursWorked.AutoSize = true;
            this.lblHoursWorked.Location = new System.Drawing.Point(27, 332);
            this.lblHoursWorked.Name = "lblHoursWorked";
            this.lblHoursWorked.Size = new System.Drawing.Size(111, 20);
            this.lblHoursWorked.TabIndex = 2;
            this.lblHoursWorked.Text = "Hours Worked";
            // 
            // lblRatePerHour
            // 
            this.lblRatePerHour.AutoSize = true;
            this.lblRatePerHour.Location = new System.Drawing.Point(27, 388);
            this.lblRatePerHour.Name = "lblRatePerHour";
            this.lblRatePerHour.Size = new System.Drawing.Size(110, 20);
            this.lblRatePerHour.TabIndex = 3;
            this.lblRatePerHour.Text = "Rate per Hour";
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(200, 276);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(356, 26);
            this.txtEmployeeName.TabIndex = 4;
            // 
            // txtHoursWorked
            // 
            this.txtHoursWorked.Location = new System.Drawing.Point(200, 329);
            this.txtHoursWorked.Name = "txtHoursWorked";
            this.txtHoursWorked.Size = new System.Drawing.Size(356, 26);
            this.txtHoursWorked.TabIndex = 5;
            // 
            // txtRatePerHour
            // 
            this.txtRatePerHour.Location = new System.Drawing.Point(200, 385);
            this.txtRatePerHour.Name = "txtRatePerHour";
            this.txtRatePerHour.Size = new System.Drawing.Size(356, 26);
            this.txtRatePerHour.TabIndex = 6;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(31, 445);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 30);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(152, 445);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 30);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(456, 445);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(100, 30);
            this.btnCompute.TabIndex = 9;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = false;
            this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
            // 
            // dgvAllEmployees
            // 
            this.dgvAllEmployees.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dgvAllEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAllEmployees.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvEmployeeName,
            this.dgvHoursWorked,
            this.dgvRatePerHour,
            this.dgvGrossPay,
            this.dgvDeduction,
            this.dgvNetPay});
            this.dgvAllEmployees.Location = new System.Drawing.Point(31, 70);
            this.dgvAllEmployees.Name = "dgvAllEmployees";
            this.dgvAllEmployees.RowHeadersWidth = 62;
            this.dgvAllEmployees.RowTemplate.Height = 28;
            this.dgvAllEmployees.Size = new System.Drawing.Size(525, 159);
            this.dgvAllEmployees.TabIndex = 10;
            // 
            // dgvEmployeeName
            // 
            this.dgvEmployeeName.HeaderText = "Employee Name";
            this.dgvEmployeeName.MinimumWidth = 8;
            this.dgvEmployeeName.Name = "dgvEmployeeName";
            this.dgvEmployeeName.ReadOnly = true;
            this.dgvEmployeeName.Width = 150;
            // 
            // dgvHoursWorked
            // 
            this.dgvHoursWorked.HeaderText = "Hours Worked";
            this.dgvHoursWorked.MinimumWidth = 8;
            this.dgvHoursWorked.Name = "dgvHoursWorked";
            this.dgvHoursWorked.ReadOnly = true;
            this.dgvHoursWorked.Width = 150;
            // 
            // dgvRatePerHour
            // 
            this.dgvRatePerHour.HeaderText = "Rate per Hour";
            this.dgvRatePerHour.MinimumWidth = 8;
            this.dgvRatePerHour.Name = "dgvRatePerHour";
            this.dgvRatePerHour.ReadOnly = true;
            this.dgvRatePerHour.Width = 150;
            // 
            // dgvGrossPay
            // 
            this.dgvGrossPay.HeaderText = "Gross Pay";
            this.dgvGrossPay.MinimumWidth = 8;
            this.dgvGrossPay.Name = "dgvGrossPay";
            this.dgvGrossPay.ReadOnly = true;
            this.dgvGrossPay.Width = 150;
            // 
            // dgvDeduction
            // 
            this.dgvDeduction.HeaderText = "Deduction";
            this.dgvDeduction.MinimumWidth = 8;
            this.dgvDeduction.Name = "dgvDeduction";
            this.dgvDeduction.ReadOnly = true;
            this.dgvDeduction.Width = 150;
            // 
            // dgvNetPay
            // 
            this.dgvNetPay.HeaderText = "Net Pay";
            this.dgvNetPay.MinimumWidth = 8;
            this.dgvNetPay.Name = "dgvNetPay";
            this.dgvNetPay.ReadOnly = true;
            this.dgvNetPay.Width = 150;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(28, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(452, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "*Employee information iside DataGridView will show once you click run.";
            // 
            // lblTitle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 493);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvAllEmployees);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtRatePerHour);
            this.Controls.Add(this.txtHoursWorked);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.lblRatePerHour);
            this.Controls.Add(this.lblHoursWorked);
            this.Controls.Add(this.lblEmployeeName);
            this.Controls.Add(this.label1);
            this.Name = "lblTitle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payroll System";
            this.Load += new System.EventHandler(this.PayrollSystem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllEmployees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label lblHoursWorked;
        private System.Windows.Forms.Label lblRatePerHour;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.TextBox txtHoursWorked;
        private System.Windows.Forms.TextBox txtRatePerHour;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCompute;
        private System.Windows.Forms.DataGridView dgvAllEmployees;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvEmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvHoursWorked;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvRatePerHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvGrossPay;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvDeduction;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvNetPay;
        private System.Windows.Forms.Label label2;
    }
}

