﻿/*
 Instructions:
 Simple Payroll System
    Objective: Compute employee salary based on hours worked.
    Requirements:

        Input: 
            Employee Name, Hours Worked, Rate per Hour

        Compute:
            Gross Pay = Hours × Rate
            Deduction = 10% of Gross
            Net Pay = Gross − Deduction
            Display in labels or a summary MessageBox.
            Include “Clear” and “Exit.”

        Bonus: 
            Use DataGridView to show multiple employees’ salaries.

        Key Topics: 
            Arithmetic, form controls, formatting currency.

  To-Dos:
    1. Designan ang form [DONE]
    2. Implement calculation logic for gross pay, deduction, and net pay. [DONE]
    3. Display results in MessageBox. [DONE]
    4. Add functionality for "Clear" and "Exit" buttons. [DONE]
    5. (Bonus) Integrate DataGridView for multiple employees. [DONE]
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Madayag_W4W3
{
    public partial class lblTitle : Form
    {
        public lblTitle()
        {
            InitializeComponent();
        }

        // Event para sa pag-run sa mismong form, mu-load na ni daan
        private void PayrollSystem_Load(object sender, EventArgs e)
        {
            // Sample rows
            // Employee Name, Hours Worked, Rate per Hour, Gross Pay, Deduction, Net Pay

            // Employee 1
            dgvAllEmployees.Rows.Add("Ken Zebasi", 10,
                100.ToString("C"),
                1000.ToString("C"),
                100.ToString("C"),
                900.ToString("C")
            );

            // Employee 2
            dgvAllEmployees.Rows.Add("King Cymanti", 8,
                120.ToString("C"),
                960.ToString("C"),
                96.ToString("C"),
                864.ToString("C")
            );

            // Employee 3
            dgvAllEmployees.Rows.Add("Sixx Polaris", 12,
                150.ToString("C"),
                1800.ToString("C"),
                180.ToString("C"),
                1620.ToString("C")
            );
        }

        // Compute Button
        private void btnCompute_Click(object sender, EventArgs e)
        {
            Payroll1 payroll = new Payroll1()
            {
                employeeName = txtEmployeeName.Text,
                hoursWorked = Convert.ToDouble(txtHoursWorked.Text),
                ratePerHour = Convert.ToDouble(txtRatePerHour.Text)
            };

            payroll.showCalculatePayroll();

        }

        // Exit Button
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // only close the current form
            // Application.Exit(); // close the entire application
        }

        // Clear Button
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEmployeeName.Clear();
            txtHoursWorked.Clear();
            txtRatePerHour.Clear();
        }
    }
}
