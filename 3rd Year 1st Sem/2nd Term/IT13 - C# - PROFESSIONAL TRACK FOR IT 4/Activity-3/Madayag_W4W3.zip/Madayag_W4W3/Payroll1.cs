﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Madayag_W4W3
{
    internal class Payroll1
    {
        public string employeeName { get; set; }

        public double hoursWorked { get; set; }

        public double ratePerHour { get; set; }

        public void showCalculatePayroll()
        {

            double grossPay = this.hoursWorked * this.ratePerHour;
            double deduction = grossPay * 0.10;
            double netPay = grossPay - deduction;

            MessageBox.Show( 
                $"Employee Name: {this.employeeName}\n" +
                $"Hours Worked: {this.hoursWorked}\n" +
                $"Rate per Hour: {this.ratePerHour}\n\n" +

                // w/ Currency Formatting
                $"Gross Pay: {grossPay.ToString("C")}\n" + 
                $"Deduction: {deduction.ToString("C")}\n" +
                $"Net Pay: {netPay.ToString("C")}\n"
            );
        }

    }
}
