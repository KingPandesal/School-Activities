﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadayagX
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblName.Text = "Maddy";
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblAnswer_Click(object sender, EventArgs e)
        {

        }

        private void lblAnswer_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(txtNum1.Text);
                double num2 = double.Parse(txtNum2.Text);

                double answer = num1 + num2;
                lblOp.Text = "+";
                lblAnswer.Text = answer.ToString();
            } catch (Exception ex){
                lblComment.Text = "Comment: Butangig number ang isa kay textbox or ayaw letter ang ibutang!";
            }
        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(lblMinusNum1.Text);
                double num2 = double.Parse(lblMinusNum2.Text);

                double answer = num1 - num2;
                lblMinusAnswer.Text = answer.ToString();
            } catch (Exception ex){
                lblComment.Text = "Comment: Butangig number ang isa kay textbox or ayaw letter ang ibutang!";
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { 
            double num1 = double.Parse(txtMulNum1.Text);
            double num2 = double.Parse(txtMulNum2.Text);

            double answer = num1 * num2;
            txtMulAnswer.Text = answer.ToString();}
            catch (Exception ex)
            {
                lblComment.Text = "Comment: Butangig number ang isa kay textbox or ayaw letter ang ibutang!";
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            try { 
            double num1 = double.Parse(txtDivNum1.Text);
            double num2 = double.Parse(txtDivNum2.Text);

            double answer = num1 / num2;
            lblDivAnswer.Text = answer.ToString();
            }
            catch (Exception ex)
            {
                lblComment.Text = "Comment: Butangig number ang isa kay textbox or ayaw letter ang ibutang!";
            }
        }

        private void lblComment_Click(object sender, EventArgs e)
        {

        }
    }
}
