﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Madayag_LabExam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            Payroll1 payroll1 = new Payroll1()
            {
                employeeName = txtEmployeeName.Text,
                hoursWorked = Convert.ToDecimal(txtHoursWorked.Text),
                ratePerHour = Convert.ToDecimal(txtRatePerHour.Text),
            };

            payroll1.calculatePayroll();

            dgvAllEmployees.Rows.Add(
                payroll1.employeeName, 
                payroll1.hoursWorked, 
                payroll1.ratePerHour,
                payroll1.grossPay,
                payroll1.deduction,
                payroll1.netPay
            );
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEmployeeName.Clear();
            txtHoursWorked.Clear();
            txtRatePerHour.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgvAllEmployees.Rows.Add("Ken", 100, 100, 100, 100, 100);
            dgvAllEmployees.Rows.Add("Madayag", 100, 100, 100, 100, 100);
        }
    }
}
