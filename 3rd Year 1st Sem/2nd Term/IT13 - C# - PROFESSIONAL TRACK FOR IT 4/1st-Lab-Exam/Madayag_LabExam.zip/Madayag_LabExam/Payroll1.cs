﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Madayag_LabExam
{
    internal class Payroll1
    {
        public string employeeName {  get; set; }

        public decimal hoursWorked { get; set; }

        public decimal ratePerHour { get; set; }

        public decimal grossPay { get; set; }

        public decimal deduction { get; set; }

        public decimal netPay { get; set; }

        public void calculatePayroll()
        {
            decimal percentDeduction = 0.10M;

             grossPay = hoursWorked * ratePerHour;
             deduction = percentDeduction * grossPay;
             netPay = grossPay - deduction;

            MessageBox.Show(
                $"Employee Name: {this.employeeName}\n" +
                $"Hours Worked: {this.hoursWorked}\n" +
                $"Rate per Hour: {this.ratePerHour}\n\n" +

                $"Grosspay: P{grossPay}\n" +
                $"Deduction: P{deduction}\n" +
                $"Net Pay: P{netPay}\n" 
            );
        }
    }
}
