﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Madayag_LabActivity2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblCategory_Click(object sender, EventArgs e)
        {

        }

        private void lblOrigin_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            Product1 p = new Product1()
            {
                barcode = txtBarcode.Text,
                name = txtName.Text,
                description = txtDescription.Text,
                category = cboCategory.Text,
                origin = rbtnOriginAbroad.Checked ? "Abroad" : "Local",
                isActive = chkStatusActive.Checked,
                cost = 100,
                price = Convert.ToDecimal(txtPrice.Text),
                markup = Convert.ToDecimal(txtMarkup.Text)
            };

            p.showProduct();

        }
    }
}
